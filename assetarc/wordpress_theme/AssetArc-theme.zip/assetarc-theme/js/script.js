document.addEventListener('DOMContentLoaded', function () {
  const vaultForm = document.getElementById('vault-login');
  const vaultDocs = document.getElementById('vault-documents');
  const vaultContent = document.getElementById('vault-content');

  if (vaultForm) {
    vaultForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const token = document.getElementById('token').value;

      try {
        const res = await fetch('/wp-content/themes/assetarc-theme/vault-access.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ token: token }),
        });

        const data = await res.json();
        if (data.success) {
          vaultForm.classList.add('hidden');
          vaultDocs.classList.remove('hidden');
          vaultContent.innerHTML = data.documents.map(doc => `<div class="p-4 bg-gray-800 rounded"><a href="${doc.url}" target="_blank">${doc.name}</a></div>`).join('');
        } else {
          alert('Invalid token. Try again.');
        }
      } catch (err) {
        alert('Error unlocking vault.');
      }
    });
  }
});
