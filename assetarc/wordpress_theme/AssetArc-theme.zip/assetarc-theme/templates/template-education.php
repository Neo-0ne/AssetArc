<?php
/**
 * Template Name: Education
 */

get_header();
?>

<main class="education-page bg-black text-white py-16 px-6 lg:px-24">
    <div class="max-w-screen-xl mx-auto">

        <h1 class="text-4xl lg:text-5xl font-semibold mb-10 text-gold">Education Hub</h1>

        <section class="mb-16">
            <p class="text-lg text-gray-300 max-w-3xl">
                The structuring world is complex — but it doesn’t have to be inaccessible. We’ve created a full ecosystem of resources to help you think smarter, act earlier, and structure with intent.
            </p>
        </section>

        <section class="mb-20 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <!-- Podcast -->
            <div class="bg-gray-900 p-6 rounded-xl shadow hover:shadow-lg transition">
                <h2 class="text-xl font-semibold text-gold mb-2">🎙 Podcast</h2>
                <p class="text-gray-400 mb-4">
                    Dive deep with weekly episodes on tax strategy, jurisdiction breakdowns, and legacy design.
                </p>
                <a href="/podcast" class="text-gold hover:underline">Explore episodes →</a>
            </div>

            <!-- Blog -->
            <div class="bg-gray-900 p-6 rounded-xl shadow hover:shadow-lg transition">
                <h2 class="text-xl font-semibold text-gold mb-2">📚 Blog</h2>
                <p class="text-gray-400 mb-4">
                    In-depth explainers and insights to help you avoid pitfalls, discover strategy, and plan with clarity.
                </p>
                <a href="/blog" class="text-gold hover:underline">Read the blog →</a>
            </div>

            <!-- Course -->
            <div class="bg-gray-900 p-6 rounded-xl shadow hover:shadow-lg transition">
                <h2 class="text-xl font-semibold text-gold mb-2">🎓 Course</h2>
                <p class="text-gray-400 mb-4">
                    Enroll in our private, expert-led course: structure, protect, and scale your wealth with precision.
                </p>
                <a href="/course" class="text-gold hover:underline">View curriculum →</a>
            </div>
        </section>

        <section class="mt-20 text-center">
            <h2 class="text-2xl lg:text-3xl font-bold text-white mb-4">New to Structuring?</h2>
            <p class="mb-6 text-gray-400 max-w-2xl mx-auto">
                Start with our free Structuring Guide — your first step toward a legacy that endures.
            </p>
            <a href="/lead-magnet" class="inline-block bg-gold text-black font-semibold px-6 py-3 rounded-full hover:bg-yellow-400 transition">
                Download the Guide
            </a>
        </section>

    </div>
</main>

<?php
get_footer();
?>
