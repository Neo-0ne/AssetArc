<?php
/*
Template Name: Vault Page
*/
get_header(); ?>

<main class="p-8 text-white max-w-5xl mx-auto">
  <h1 class="text-4xl font-bold mb-4">Your Asset Vault</h1>
  <p class="mb-6">Welcome to your secure structuring vault. Below are your available documents, templates, or advisor notes.</p>

  <div class="bg-gray-800 p-6 rounded shadow mb-6">
    <h2 class="text-xl text-gold mb-2">📄 IBC Structure Pack – Approved</h2>
    <a href="/vault/downloads/ibc-package.pdf" class="underline text-gold">Download Now</a>
  </div>

  <div class="bg-gray-800 p-6 rounded shadow mb-6">
    <h2 class="text-xl text-gold mb-2">📄 Tax Optimisation Summary – Reviewed</h2>
    <a href="/vault/downloads/tax-summary.pdf" class="underline text-gold">Download Now</a>
  </div>

  <p class="mt-10 text-sm text-gray-400 italic">Note: Only advisor-approved files appear here. Contact support if your vault is empty.</p>
</main>

<?php get_footer(); ?>
