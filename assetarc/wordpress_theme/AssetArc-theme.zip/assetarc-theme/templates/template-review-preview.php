<?php
/**
 * Template Name: Review Preview
 * Description: Displays flagged documents awaiting human review.
 */

get_header(); ?>

<main class="container mx-auto px-4 py-8 text-white">
  <h1 class="text-3xl font-bold mb-4 border-b border-gray-700 pb-2">🚩 Documents Flagged for Review</h1>

  <?php
  // Sample placeholder directory — change this to your actual uploads/review folder
  $review_dir = get_stylesheet_directory() . '/flagged-documents/';
  $review_url = get_stylesheet_directory_uri() . '/flagged-documents/';

  if (file_exists($review_dir)) {
      $files = array_diff(scandir($review_dir), array('.', '..'));

      if (count($files) > 0) {
          echo '<ul class="space-y-2">';
          foreach ($files as $file) {
              $file_path = $review_dir . $file;
              $file_url = $review_url . $file;

              echo '<li class="bg-gray-800 p-4 rounded shadow hover:bg-gray-700 transition">';
              echo '<a href="' . esc_url($file_url) . '" target="_blank" class="underline text-yellow-400">';
              echo esc_html($file);
              echo '</a>';
              echo '</li>';
          }
          echo '</ul>';
      } else {
          echo '<p class="text-gray-400">No documents currently flagged for review.</p>';
      }
  } else {
      echo '<p class="text-red-500">Review directory not found. Please create a folder called <code>/flagged-documents/</code> inside your theme.</p>';
  }
  ?>
</main>

<?php get_footer(); ?>
