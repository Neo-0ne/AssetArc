Bot: Risk Assessment Bot
Purpose: Evaluate risks and generate a summary report based on likelihood and severity scores.