
Metrics Dashboard Bot

This Flask app serves personalized metric data based on user type.
Supported types: client, advisor, admin.

Endpoints:
GET /metrics?user_type=client
GET /metrics?user_type=advisor
GET /metrics?user_type=admin

Make sure to have the relevant JSON files in the same folder as the bot.
