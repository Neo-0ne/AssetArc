# AssetArc Master Bot Directory

This folder contains all core scripts required to manage and test bots.