Suggest-a-Service Bot

This bot analyzes user input to detect unmet service needs and routes them to the correct structuring bot or flags them for advisor follow-up.

Files:
- suggest_service_bot.py : main logic to match keywords to service recommendations
- README.txt : this file

Instructions:
1. Run suggest_service_bot.py with user input as test.
2. Integrate with Notion intake by capturing unmatched or human-routed queries.

No internet connection is required. All logic is locally processed.
