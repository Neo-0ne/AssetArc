Suggest_a_Service_Bot
------------------
Purpose: Auto-suggest the most relevant bot for a user’s request, and send it to Notion intake.

How to Run:
1. Open terminal or command prompt.
2. Run: python Suggest_a_Service_Bot.py
3. Enter a short query describing the user’s need.
4. The bot will suggest a relevant service and simulate submission to Notion.

No additional dependencies needed.
