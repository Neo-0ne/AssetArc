Review Flag Monitor Bot
-------------------------

This bot reads a JSON list of sessions and identifies those flagged for review,
outputting their ID, reason, and user comments.

Files:
- Review_Flag_Monitor_Bot.py: Main logic
- flagged_input.txt: Sample JSON input
- README.txt: This guide

To run:
python Review_Flag_Monitor_Bot.py
