Lead Magnet Bot
===============

This bot lets users select a lead magnet document (PDF) and logs their email and selected file.
It is intended for capturing leads and triggering follow-up sequences.

INSTRUCTIONS:
1. Run the script: python lead_magnet_bot.py
2. Enter email and select document
3. Download link message is returned and logged.

Make sure to pre-populate the document folder with:
- trust_setup_guide.pdf
- offshore_structuring_guide.pdf
- asset_protection_blueprint.pdf