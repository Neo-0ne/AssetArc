// React Embed (Trust Setup Bot)
import TrustSetupBot from './components/TrustSetupBot';

function App() {
  return (
    <div className="App">
      <TrustSetupBot />
    </div>
  );
}

export default App;