# UI Flow for Client Intake & FICA Bot

[Flow diagram placeholder]