# UI Flow for Legal Entity Linking Bot

[Flow diagram placeholder]